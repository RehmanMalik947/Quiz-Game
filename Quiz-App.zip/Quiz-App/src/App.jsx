import './App.css'
import Page from './Components/Page'


function App() {

  return (
    <>
     <Page/>
    </>
  )
}

export default App
