import React from "react";
import "./Page.css";
import { questions } from "./Questions_List";
import { useState } from "react";

const Page = () => {
  let [count, setCount] = useState(0);
  let [check, setCheck] = useState(0);
  let [finished, setFinished] = useState(false);
  let object = questions[count];

  return (
    <div className="app">
      <h1>Simple Quiz</h1>
      {!finished ? (
        <div className="quiz">
          <div>
            <div className="Question-container">
              <div className="number">{count + 1}:</div>
              <h2 className="Question">{object.statement}</h2>
            </div>
            {object.options.map((item) => (
              <div className="answer-btns" key={item.text}>
                <button
                  className="btn"
                  onClick={() => {
                    if (item.correct === true) {
                      setCheck(check + 1);
                    }
                  }}
                >
                  {item.text}
                </button>
              </div>
            ))}
          </div>

          <div className="current">
            <span>
              {count + 1} of 4
            </span>
          </div>

          {count === 3 ? (
            <button className="nbtn" onClick={() => setFinished(true)}>
              See Result
            </button>
          ) : (
            <button
              className="nbtn"
              onClick={() => {
                if (count < questions.length - 1) {
                  setCount(count + 1);
                }
              }}
            >
              Next jee
            </button>
          )}
        </div>
      ) : (
        <div className="result">
          <h2>Your Score: {check} / 4</h2>
          <button className="nbtn" onClick={() => window.location.reload()}>
            Restart Quiz
          </button>
        </div>
      )}
    </div>
  );
};
export default Page;