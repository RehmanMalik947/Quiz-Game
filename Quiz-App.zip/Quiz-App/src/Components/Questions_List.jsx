export const questions=
[
    {
        id:1,
        statement: "1 + 1",
        options:
        [
            {text:"1",  correct:false},
            {text:"2",correct:true},
            {text:"3", correct:false},
            {text:"4", correct:false},
        ]
    },
    {
        id:2,
        statement: "one + two",
        options:
        [
            {text:"two",  correct:false},
            {text:"three",correct:true},
            {text:"four", correct:false},
            {text:"five", correct:false},
        ]
    },
    {
        id:3,
        statement: "I + III",
        options:
        [
            {text:"I",  correct:false},
            {text:"II",correct:false},
            {text:"III", correct:false},
            {text:"IV", correct:true},
        ]
    },
    {
        id:4,
        statement: "1 + 4",
        options:
        [
            {text:"two",  correct:false},
            {text:"three",correct:false},
            {text:"four", correct:false},
            {text:"five", correct:true},
        ]
    }
];